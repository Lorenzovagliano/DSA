#include "TreeNode.hpp"

TreeNode::TreeNode(std::string x){
    this->val = x;
    this->left = this->right = NULL;
}
