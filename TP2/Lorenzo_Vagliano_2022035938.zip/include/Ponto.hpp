#ifndef PONTO_H
#define PONTO_H

#include <iostream>

class Ponto{
    public:
        int x;
        int y;

        Ponto();
        Ponto(int _x, int _y);
};

#endif