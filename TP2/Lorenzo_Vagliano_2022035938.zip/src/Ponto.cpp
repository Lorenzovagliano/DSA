#include "Ponto.hpp"

Ponto::Ponto(){
    this->x = NULL;
    this->y = NULL;
}

Ponto::Ponto(int _x, int _y){
    this->x = _x;
    this->y = _y;
}