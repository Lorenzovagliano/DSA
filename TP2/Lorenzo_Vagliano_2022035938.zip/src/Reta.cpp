#include "Reta.hpp"

Reta::Reta(Ponto _p1, Ponto _p2){
    this->p1 =_p1;
    this->p2 = _p2;
}